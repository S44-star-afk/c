/* ============================================================================
   Migration 008 - Catégories et sous-catégories d'activité quotidienne
   Demande client du 13/08/2026.

   Ajoute deux référentiels ADMINISTRABLES (gérés depuis l'écran) :
     dbo.categorie        - grands thèmes en majuscules (INCIDENTS, RUN, FT MEETING…)
     dbo.sous_categorie   - détail rattaché à une catégorie (Mineur, Majeur, IG…)
   et une colonne FACULTATIVE dbo.saisie_activite.sous_categorie_id.

   Le champ TTK existant est CONSERVÉ ; catégorie/sous-catégorie viennent EN PLUS.

   Idempotent (réexécutable sans dégât) et SANS dépendance au journal de
   migration : fonctionne aussi sur une base créée à la main.
     sqlcmd -S <serveur> -d cra -b -i 008_categories.sql
   ============================================================================ */

SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* Étape 1 - référentiel catégorie ---------------------------------------- */
IF OBJECT_ID(N'dbo.categorie', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.categorie
    (
        id          INT            IDENTITY(1,1) NOT NULL,
        code        NVARCHAR(40)   NOT NULL,
        libelle     NVARCHAR(100)  NOT NULL,   -- nom affiché, en majuscules
        ordre       INT            NOT NULL CONSTRAINT DF_categorie_ordre DEFAULT (0),
        est_actif   BIT            NOT NULL CONSTRAINT DF_categorie_actif DEFAULT (1),
        cree_le     DATETIME2(3)   NOT NULL CONSTRAINT DF_categorie_cree  DEFAULT SYSUTCDATETIME(),
        modifie_le  DATETIME2(3)   NULL,
        CONSTRAINT PK_categorie PRIMARY KEY (id),
        CONSTRAINT UQ_categorie_code UNIQUE (code),
        CONSTRAINT CK_categorie_code_non_vide CHECK (LEN(LTRIM(RTRIM(code))) > 0)
    );
END;
GO

/* Étape 2 - référentiel sous_categorie ----------------------------------- */
IF OBJECT_ID(N'dbo.sous_categorie', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.sous_categorie
    (
        id            INT           IDENTITY(1,1) NOT NULL,
        categorie_id  INT           NOT NULL,
        code          NVARCHAR(60)  NOT NULL,
        libelle       NVARCHAR(100) NOT NULL,
        ordre         INT           NOT NULL CONSTRAINT DF_souscat_ordre DEFAULT (0),
        est_actif     BIT           NOT NULL CONSTRAINT DF_souscat_actif DEFAULT (1),
        cree_le       DATETIME2(3)  NOT NULL CONSTRAINT DF_souscat_cree  DEFAULT SYSUTCDATETIME(),
        modifie_le    DATETIME2(3)  NULL,
        CONSTRAINT PK_sous_categorie PRIMARY KEY (id),
        CONSTRAINT UQ_sous_categorie_code UNIQUE (code),
        CONSTRAINT FK_sous_categorie_categorie FOREIGN KEY (categorie_id) REFERENCES dbo.categorie (id),
        CONSTRAINT CK_souscat_code_non_vide CHECK (LEN(LTRIM(RTRIM(code))) > 0)
    );
    CREATE NONCLUSTERED INDEX IX_sous_categorie_categorie
        ON dbo.sous_categorie (categorie_id) INCLUDE (libelle, est_actif);
END;
GO

/* Étape 3 - colonne facultative sur saisie_activite + FK ----------------- */
IF COL_LENGTH(N'dbo.saisie_activite', N'sous_categorie_id') IS NULL
BEGIN
    ALTER TABLE dbo.saisie_activite ADD sous_categorie_id INT NULL;
END;
GO
IF COL_LENGTH(N'dbo.saisie_activite', N'sous_categorie_id') IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_saisie_sous_categorie')
BEGIN
    ALTER TABLE dbo.saisie_activite WITH CHECK
        ADD CONSTRAINT FK_saisie_sous_categorie
        FOREIGN KEY (sous_categorie_id) REFERENCES dbo.sous_categorie (id);
END;
GO

/* Étape 4 - données initiales : catégories (seulement celles qui manquent) */
INSERT INTO dbo.categorie (code, libelle, ordre)
SELECT v.code, v.libelle, v.ordre FROM (VALUES
    (N'INCIDENTS',                       N'INCIDENTS',                          1),
    (N'KNOWLEDGE',                       N'KNOWLEDGE',                          2),
    (N'RUN',                             N'RUN',                                3),
    (N'PROJETS_INTERNE',                 N'PROJETS INTERNE',                    4),
    (N'APPS_INTEGRATION_CONTROL',        N'APPS INTEGRATION & CONTROL',         5),
    (N'RESSOURCES_OPERATION_MNGT',       N'RESSOURCES & OPERATION MNGT',        6),
    (N'PROJECT_MANAGEMENT',              N'PROJECT MANAGEMENT',                 7),
    (N'ARCHITECTURE_PRODUITS_SOLUTIONS', N'ARCHITECTURE PRODUCTS AND SOLUTIONS',8),
    (N'FT_MEETING',                      N'FT MEETING',                         9)
) AS v(code, libelle, ordre)
WHERE NOT EXISTS (SELECT 1 FROM dbo.categorie c WHERE c.code = v.code);
GO

/* Étape 5 - données initiales : sous-catégories (rattachées par code catégorie) */
;WITH sc(cat_code, code, libelle, ordre) AS (
    SELECT * FROM (VALUES
        (N'INCIDENTS', N'INCIDENTS__MINEUR',     N'Mineur',     1),
        (N'INCIDENTS', N'INCIDENTS__MAJEUR',     N'Majeur',     2),
        (N'INCIDENTS', N'INCIDENTS__IG',         N'IG',         3),
        (N'INCIDENTS', N'INCIDENTS__TASK_FORCE', N'TASK FORCE', 4),

        (N'KNOWLEDGE', N'KNOWLEDGE__CUSTOMER_FORMATIONS', N'Customer Formations', 1),
        (N'KNOWLEDGE', N'KNOWLEDGE__KNOWLEDGE_TRANSFERT', N'Knowledge Transfert', 2),
        (N'KNOWLEDGE', N'KNOWLEDGE__TECHNICAL_TRAINING',  N'Technical Training',  3),

        (N'RUN', N'RUN__SARA',        N'SARA',        1),
        (N'RUN', N'RUN__WORKSTATION', N'Workstation', 2),
        (N'RUN', N'RUN__XAS',         N'XAS',         3),
        (N'RUN', N'RUN__VDI',         N'VDI',         4),
        (N'RUN', N'RUN__SECURITY',    N'SECURITY',    5),

        (N'PROJETS_INTERNE', N'PROJETS_INTERNE__SARA',        N'SARA',        1),
        (N'PROJETS_INTERNE', N'PROJETS_INTERNE__WORKSTATION', N'Workstation', 2),
        (N'PROJETS_INTERNE', N'PROJETS_INTERNE__XAS',         N'XAS',         3),
        (N'PROJETS_INTERNE', N'PROJETS_INTERNE__VDI',         N'VDI',         4),
        (N'PROJETS_INTERNE', N'PROJETS_INTERNE__SECURITY',    N'SECURITY',    5),
        (N'PROJETS_INTERNE', N'PROJETS_INTERNE__MEETING',     N'Meeting',     6),

        (N'APPS_INTEGRATION_CONTROL', N'APPS_INTEGRATION_CONTROL__SIMPLE',   N'Simple',   1),
        (N'APPS_INTEGRATION_CONTROL', N'APPS_INTEGRATION_CONTROL__COMPLEX',  N'Complex',  2),
        (N'APPS_INTEGRATION_CONTROL', N'APPS_INTEGRATION_CONTROL__SENSIBLE', N'Sensible', 3),

        (N'RESSOURCES_OPERATION_MNGT', N'RESSOURCES_OPERATION_MNGT__REPORTING',        N'Reporting',         1),
        (N'RESSOURCES_OPERATION_MNGT', N'RESSOURCES_OPERATION_MNGT__ACTIVITY_TRACKING',N'Activity tracking', 2),
        (N'RESSOURCES_OPERATION_MNGT', N'RESSOURCES_OPERATION_MNGT__BILLING',          N'Billing',           3),
        (N'RESSOURCES_OPERATION_MNGT', N'RESSOURCES_OPERATION_MNGT__TEAM_MANAGEMENT',  N'Team Management',   4),

        (N'PROJECT_MANAGEMENT', N'PROJECT_MANAGEMENT__COORDINATION', N'Coordination', 1),
        (N'PROJECT_MANAGEMENT', N'PROJECT_MANAGEMENT__EXPLOITATION', N'Exploitation', 2),
        (N'PROJECT_MANAGEMENT', N'PROJECT_MANAGEMENT__MEETING',      N'Meeting',      3),

        (N'ARCHITECTURE_PRODUITS_SOLUTIONS', N'ARCHI__AUDIT',            N'Audit',            1),
        (N'ARCHITECTURE_PRODUITS_SOLUTIONS', N'ARCHI__COORDINATION',     N'Coordination',     2),
        (N'ARCHITECTURE_PRODUITS_SOLUTIONS', N'ARCHI__INTEGRATION',      N'Intégration',      3),
        (N'ARCHITECTURE_PRODUITS_SOLUTIONS', N'ARCHI__EXPLOITATION',     N'Exploitation',     4),
        (N'ARCHITECTURE_PRODUITS_SOLUTIONS', N'ARCHI__TECHNOLOGY_WATCH', N'Technology watch', 5),
        (N'ARCHITECTURE_PRODUITS_SOLUTIONS', N'ARCHI__MEETING',          N'Meeting',          6),

        (N'FT_MEETING', N'FT_MEETING__PRINTING',     N'Printing',     1),
        (N'FT_MEETING', N'FT_MEETING__BEYOND_TRUST', N'Beyond Trust', 2),
        (N'FT_MEETING', N'FT_MEETING__BROWSING',     N'Browsing',     3),
        (N'FT_MEETING', N'FT_MEETING__OFFICE',       N'Office',       4),
        (N'FT_MEETING', N'FT_MEETING__SGADM',        N'SGADM',        5),
        (N'FT_MEETING', N'FT_MEETING__ADSAF',        N'Adsaf',        6),
        (N'FT_MEETING', N'FT_MEETING__WORKSTATION',  N'Workstation',  7),
        (N'FT_MEETING', N'FT_MEETING__HARDWARE',     N'Hardware',     8),
        (N'FT_MEETING', N'FT_MEETING__NOVA',         N'Nova',         9),
        (N'FT_MEETING', N'FT_MEETING__CITRIX_APPS',  N'Citrix Apps',  10),
        (N'FT_MEETING', N'FT_MEETING__XAS',          N'Xas',          11),
        (N'FT_MEETING', N'FT_MEETING__SARA',         N'Sara',         12),
        (N'FT_MEETING', N'FT_MEETING__VDI',          N'VDI',          13),
        (N'FT_MEETING', N'FT_MEETING__CONNECTIVITY', N'Connectivity', 14),
        (N'FT_MEETING', N'FT_MEETING__PEPSI',        N'Pepsi',        15),
        (N'FT_MEETING', N'FT_MEETING__CONTROL',      N'Control',      16),
        (N'FT_MEETING', N'FT_MEETING__MASTER',       N'Master',       17)
    ) AS x(cat_code, code, libelle, ordre)
)
INSERT INTO dbo.sous_categorie (categorie_id, code, libelle, ordre)
SELECT c.id, sc.code, sc.libelle, sc.ordre
FROM sc JOIN dbo.categorie c ON c.code = sc.cat_code
WHERE NOT EXISTS (SELECT 1 FROM dbo.sous_categorie s WHERE s.code = sc.code);
GO

/* Étape 6 - droits du compte applicatif (pas de suppression physique) ----- */
IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'cra_app')
BEGIN
    GRANT SELECT, INSERT, UPDATE ON OBJECT::dbo.categorie      TO [cra_app];
    GRANT SELECT, INSERT, UPDATE ON OBJECT::dbo.sous_categorie TO [cra_app];
    DENY  DELETE                  ON OBJECT::dbo.categorie      TO [cra_app];
    DENY  DELETE                  ON OBJECT::dbo.sous_categorie TO [cra_app];
END;
GO

/* Étape 6b - renommage d'affichage du rôle socle : Technicien -> Consultant
   (demande client du 14/08 ; le CODE reste TECHNICIEN, seul le libellé change,
   donc aucun droit n'est impacté). */
IF OBJECT_ID(N'dbo.role', N'U') IS NOT NULL
BEGIN
    UPDATE dbo.role SET libelle = N'Consultant'
    WHERE code = N'TECHNICIEN' AND libelle <> N'Consultant';
END;
GO

/* Étape 7 - journal de migration (si présent) ---------------------------- */
IF OBJECT_ID(N'dbo.migration_journal', N'U') IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM dbo.migration_journal WHERE script_nom = N'008_categories')
BEGIN
    INSERT INTO dbo.migration_journal (script_nom) VALUES (N'008_categories');
END;
PRINT N'Migration 008_categories appliquée : catégories + sous-catégories + colonne saisie.';
GO
