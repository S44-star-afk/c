param(
    [string]$Dossier = "D:\_APPS\IIS\cra",
    [string]$Instance = ".\SQLEXPRESS",
    [string]$MotDePasseCraApp = ""
)
$ErrorActionPreference = "Continue"

function Ok($t) { Write-Host "[OK] $t" -ForegroundColor Green }
function Ko($t) { Write-Host "[KO] $t" -ForegroundColor Red }
function Nb($t) { Write-Host "[--] $t" -ForegroundColor Yellow }
function L($t)  { Write-Host "     $t" -ForegroundColor Gray }
function S($t)  { Write-Host ""; Write-Host "== $t ==" -ForegroundColor Cyan }

$dbn = "cra"

S "Contexte"
try {
    if ((& dotnet --list-runtimes 2>$null) -match "Microsoft\.AspNetCore\.App 10\.") { Ok "runtime ASP.NET Core 10" }
    else { Ko "runtime ASP.NET Core 10 absent" }
} catch { Ko "dotnet absent" }

S "Application ($Dossier)"
if (Test-Path (Join-Path $Dossier "Cra.Web.dll")) { Ok "Cra.Web.dll" } else { Ko "Cra.Web.dll absent" }
$hashes = @{
    "System.Configuration.ConfigurationManager.dll"  = "8C5DC3E409C45F07D6BD9E86F55983738AF79228D9E45DB2CAE8F411C24265DD"
    "System.Runtime.Caching.dll"                     = "14A5C2C275671D82210BA35902B170CBCF7CBB0D53FCDC16DBC1E659A39BA6CA"
    "System.Security.Cryptography.ProtectedData.dll" = "CC27E292148D8AFB7F34916EC257FAF8284E4D3FB74189A92CD14CF84D8BA49B"
}
foreach ($n in $hashes.Keys) {
    $p = Join-Path $Dossier $n
    if (-not (Test-Path $p)) { Ko "$n absent"; continue }
    if ((Get-FileHash $p -Algorithm SHA256).Hash -eq $hashes[$n]) { Ok "$n (Windows)" }
    else { Ko "$n mauvaise version (Linux ?)" }
}

S "Configuration"
$connStr = $null; $srv = $null
$envc = [Environment]::GetEnvironmentVariable("CRA_CONNEXION", "Machine")
if ($envc) { $connStr = $envc; Ok "source : CRA_CONNEXION" }
else {
    $cfg = Join-Path $Dossier "configuration.json"
    if (Test-Path $cfg) {
        try { $connStr = (Get-Content $cfg -Raw | ConvertFrom-Json).chaineConnexion; Ok "source : configuration.json" }
        catch { Ko "configuration.json illisible"; L $_.Exception.Message }
    } else { Ko "aucune configuration (CRA_CONNEXION / configuration.json)" }
}
if ($connStr) {
    L ([Regex]::Replace($connStr, "(?i)(password\s*=\s*)([^;]+)", '$1********'))
    $srv = ([Regex]::Match($connStr, "(?i)(server|data source)\s*=\s*([^;]+)")).Groups[2].Value.Trim()
    $pwd = ([Regex]::Match($connStr, "(?i)password\s*=\s*([^;]+)")).Groups[1].Value.Trim()
    $dbx = ([Regex]::Match($connStr, "(?i)(database|initial catalog)\s*=\s*([^;]+)")).Groups[2].Value.Trim()
    if ($dbx) { $dbn = $dbx }
    if (-not $pwd -or $pwd -eq "A_REMPLIR") { Ko "mot de passe non renseigne (A_REMPLIR)" }
    if ($srv -match ",") { Ok "Server = port explicite ($srv)" }
    elseif ($srv -match "\\") { Nb "Server = instance nommee ($srv) : TCP exige SQL Browser, preferer 127.0.0.1,1433" }
    if (-not $MotDePasseCraApp -and $pwd -and $pwd -ne "A_REMPLIR") { $MotDePasseCraApp = $pwd }
}

S "SQL Server"
$svc = Get-Service 'MSSQL$SQLEXPRESS' -ErrorAction SilentlyContinue
if ($svc) { if ($svc.Status -eq "Running") { Ok "service SQL : Running" } else { Ko "service SQL : $($svc.Status)" } }
else { Nb "service MSSQL`$SQLEXPRESS introuvable" }
$port = $null
try {
    $inst = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -ErrorAction Stop).SQLEXPRESS
    $base = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$inst"
    $lm = (Get-ItemProperty "$base\MSSQLServer" -Name LoginMode -ErrorAction SilentlyContinue).LoginMode
    if ($lm -eq 2) { Ok "LoginMode = 2 (Windows + SQL)" }
    elseif ($lm -eq 1) { Ko "LoginMode = 1 (Windows seul) : cra_app refuse" }
    $tcp = (Get-ItemProperty "$base\MSSQLServer\SuperSocketNetLib\Tcp" -Name Enabled -ErrorAction SilentlyContinue).Enabled
    if ($tcp -eq 1) { Ok "TCP/IP active" } else { Ko "TCP/IP desactive" }
    $ipall = Get-ItemProperty "$base\MSSQLServer\SuperSocketNetLib\Tcp\IPAll" -ErrorAction SilentlyContinue
    if ($ipall.TcpPort) { $port = $ipall.TcpPort; Ok "port fixe : $port" }
    elseif ($ipall.TcpDynamicPorts) { $port = $ipall.TcpDynamicPorts; Nb "port dynamique : $port" }
} catch { Nb "registre SQL non lu (lancer en admin)" }
if (-not $port) { $port = "1433" }

S "Connexions"
function T($label, $cs, $q) {
    $c = New-Object System.Data.SqlClient.SqlConnection
    $c.ConnectionString = $cs
    try { $c.Open() } catch { Ko $label; L (($_.Exception.Message -split "`n")[0]); return $false }
    Ok $label
    if ($q) { try { $cmd = $c.CreateCommand(); $cmd.CommandText = $q; L ("=> " + $cmd.ExecuteScalar()) } catch { L "requete KO" } }
    $c.Close(); return $true
}
$q = "SELECT COUNT(*) FROM dbo.role"
$A = T "A. Windows / memoire partagee ($Instance)" "Server=$Instance;Database=$dbn;Integrated Security=True;TrustServerCertificate=True;Connect Timeout=5" $q
$B = T "B. Windows / TCP 127.0.0.1,$port" "Server=tcp:127.0.0.1,$port;Database=$dbn;Integrated Security=True;TrustServerCertificate=True;Connect Timeout=5" $q
if ($MotDePasseCraApp) {
    $C = T "C. cra_app / TCP 127.0.0.1,$port" "Server=tcp:127.0.0.1,$port;Database=$dbn;User ID=cra_app;Password=$MotDePasseCraApp;TrustServerCertificate=True;Connect Timeout=5" $q
} else { Nb "C. cra_app ignore (pas de mot de passe : -MotDePasseCraApp '...')"; $C = $null }
$loginExiste = $null
if ($A) {
    try {
        $c = New-Object System.Data.SqlClient.SqlConnection
        $c.ConnectionString = "Server=$Instance;Integrated Security=True;TrustServerCertificate=True;Connect Timeout=5"
        $c.Open(); $cmd = $c.CreateCommand(); $cmd.CommandText = "SELECT COUNT(*) FROM sys.sql_logins WHERE name='cra_app'"
        $loginExiste = [int]$cmd.ExecuteScalar(); $c.Close()
        if ($loginExiste -ge 1) { Ok "login cra_app declare" } else { Ko "login cra_app absent" }
    } catch { }
}

S "Site"
try { $s = Invoke-RestMethod "http://localhost/sante" -TimeoutSec 8; if ($s.statut -eq "OK") { Ok "/sante = OK" } else { Nb "/sante = $($s.statut)" } }
catch { Nb "/sante injoignable" }

S "Verdict"
if (-not $A) {
    Ko "Base 'cra' injoignable en local : verifier service SQL, nom d'instance, migrations."
}
elseif (-not $B) {
    Ko "Base OK en local mais pas en TCP : c'est le transport."
    L 'Activer TCP + port fixe puis redemarrer :'
    L '$i=(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL").SQLEXPRESS'
    L '$k="HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$i\MSSQLServer"'
    L 'Set-ItemProperty "$k\SuperSocketNetLib\Tcp" -Name Enabled -Value 1'
    L 'Set-ItemProperty "$k\SuperSocketNetLib\Tcp\IPAll" -Name TcpPort -Value "1433"'
    L 'Set-ItemProperty "$k\SuperSocketNetLib\Tcp\IPAll" -Name TcpDynamicPorts -Value ""'
    L 'Restart-Service "MSSQL$SQLEXPRESS" -Force'
    L 'puis Server=127.0.0.1,1433 dans configuration.json'
}
elseif ($C -eq $false) {
    Ko "TCP OK mais cra_app refuse."
    if ($loginExiste -eq 0) { L "login cra_app absent : le creer (kit db\)." }
    else { L "LoginMode=1 (passer en 2) ou mot de passe config != login cra_app." }
}
elseif ($C) {
    Ok "Chemin appli complet OK (TCP + cra_app + base cra)."
    if ($srv -and $srv -notmatch ",") { Nb "configuration.json pointe '$srv' : mettre Server=127.0.0.1,$port" }
    else { L "creer-admin doit passer." }
}
elseif ($B) { Nb "Transport OK. Relancer avec -MotDePasseCraApp pour tester cra_app." }
Write-Host ""
