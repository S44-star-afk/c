# CRA — Partie web

Application web de compte rendu d'activité : saisie technicien (journées de
450 minutes, heures hors normales, astreintes, séries et récurrences,
changement de mot de passe). Hébergement IIS sur Windows Server.

Cette archive contient **uniquement la partie web**. La base de données
(schéma, migrations, installation) est gérée séparément.

## Contenu

| Dossier | Contenu |
|---|---|
| `app/publication/` | Application **déjà compilée**, prête à déposer sous IIS : `Cra.Web.dll`, le pilote SQL et toutes ses DLL, la page web (`wwwroot/`), `web.config`, le modèle `configuration.exemple.json`. |
| `app/Cra.Web/`, `app/Cra.Regles/`, `app/Cra.Tests/` | Sources (backend, règles métier, tests). |
| `app/pilotes/` | Pilote SQL officiel fourni pour reconstruire sans NuGet (provenance et empreintes dans `pilotes/PROVENANCE.txt`). |
| `app/deployer-app.ps1`, `app/construire*.ps1`, `app/tests-integration.ps1` | Scripts de déploiement, reconstruction et vérification. |
| `docs/` | `DEPLOIEMENT.txt` (mise en ligne pas à pas) et `CONNECTEURS.txt` (liaison site ↔ base). |

## Déploiement (résumé)

Détail complet dans `docs/DEPLOIEMENT.txt`.

1. Prérequis serveur : rôle IIS, puis .NET Hosting Bundle 10 (installé
   après IIS). Aucun SDK requis, l'application est fournie compilée.
2. Déposer `app/publication/` sous IIS, port 80.
3. Copier `configuration.exemple.json` en `configuration.json` et y
   renseigner la chaîne de connexion vers la base (compte SQL applicatif).
4. Créer les comptes : `dotnet .\Cra.Web.dll creer-admin admin "Administrateur"`.

Contrôle : `http://localhost/sante` doit répondre `OK` une fois la base reliée.

## Sécurité

Aucun secret dans l'archive : seul le modèle `configuration.exemple.json`
(sans mot de passe) est présent. Mots de passe hachés PBKDF2-SHA256,
verrouillage après échecs, garde anti-CSRF, requêtes SQL paramétrées,
journal d'audit en transaction.
