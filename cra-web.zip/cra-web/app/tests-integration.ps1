# CRA - tests d'integration a executer SUR LE SERVEUR apres deploiement.
# Prerequis : un compte TECHNICIEN de test, cree depuis C:\inetpub\cra :
#   dotnet .\Cra.Web.dll creer-utilisateur test.integ "Compte Test" TECHNICIEN
# Usage : .\tests-integration.ps1 -Login test.integ   (le mot de passe est demande)
param(
    [string]$Url = "http://localhost",
    [Parameter(Mandatory = $true)][string]$Login
)
$ErrorActionPreference = "Stop"
$mdp = Read-Host "Mot de passe de $Login"
$nb = 0; $ko = 0
$s = New-Object Microsoft.PowerShell.Commands.WebRequestSession

function Verif([string]$lib, [bool]$ok) {
    $script:nb++
    if ($ok) { Write-Host "OK  $lib" } else { $script:ko++; Write-Host "ECHEC $lib" -ForegroundColor Red }
}
function Api([string]$methode, [string]$chemin, $corps) {
    try {
        $p = @{ Method = $methode; Uri = "$Url$chemin"; WebSession = $s; Headers = @{ "X-CRA" = "1" }; UseBasicParsing = $true }
        if ($null -ne $corps) { $p.ContentType = "application/json"; $p.Body = ($corps | ConvertTo-Json -Depth 6) }
        $r = Invoke-WebRequest @p
        $texte = $r.Content
        return @{ Statut = [int]$r.StatusCode; Corps = $(if ($texte) { $texte | ConvertFrom-Json } else { $null }) }
    } catch {
        $rep = $_.Exception.Response
        if ($null -eq $rep) { throw }
        $lecteur = New-Object IO.StreamReader($rep.GetResponseStream())
        $texte = $lecteur.ReadToEnd()
        return @{ Statut = [int]$rep.StatusCode; Corps = $(if ($texte) { $texte | ConvertFrom-Json } else { $null }) }
    }
}

# 1. Sante
$r = Api GET "/sante" $null
Verif "sante OK (application + base)" ($r.Statut -eq 200 -and $r.Corps.statut -eq "OK")

# 2. Garde CSRF : POST sans en-tete X-CRA refuse
try {
    Invoke-WebRequest -Method POST -Uri "$Url/api/connexion" -ContentType "application/json" -Body "{}" -UseBasicParsing | Out-Null
    Verif "garde CSRF (POST sans X-CRA refuse)" $false
} catch {
    Verif "garde CSRF (POST sans X-CRA refuse)" ([int]$_.Exception.Response.StatusCode -eq 400)
}

# 3. Connexion : mauvais mot de passe refuse, bon accepte
$r = Api POST "/api/connexion" @{ login = $Login; mdp = "mauvais-mot-de-passe-x" }
Verif "mauvais mot de passe refuse (401)" ($r.Statut -eq 401)
$r = Api POST "/api/connexion" @{ login = $Login; mdp = $mdp }
Verif "connexion reussie (role TECHNICIEN)" ($r.Statut -eq 200 -and $r.Corps.roles -contains "TECHNICIEN")

# 4. Referentiels
$r = Api GET "/api/referentiels" $null
Verif "referentiels charges (TTK >= 5, feries presents)" ($r.Statut -eq 200 -and $r.Corps.ttks.Count -ge 5 -and $r.Corps.feries.Count -ge 10)
$ttk = ($r.Corps.ttks | Where-Object actif | Select-Object -First 1).id
$cible = [int]$r.Corps.minutesJourCible

# 5. Enregistrement d'une journee complete (jour ouvre le plus recent)
$jour = Get-Date
while ($jour.DayOfWeek -in "Saturday", "Sunday") { $jour = $jour.AddDays(-1) }
$iso = $jour.ToString("yyyy-MM-dd")
$ligne = @{ rubrique = "NORMALE"; dureeMinutes = $cible; ttkId = $ttk; description = "Test integration - a supprimer" }
$r = Api PUT "/api/saisies/jour/$iso" @{ jeton = $null; lignes = @($ligne) }
Verif "journee complete enregistree en base" ($r.Statut -eq 200)
$jeton = $r.Corps.jeton

# 6. Plafond : cible + 1 minute refuse
$r = Api PUT "/api/saisies/jour/$iso" @{ jeton = $jeton; lignes = @($ligne, @{ rubrique = "NORMALE"; dureeMinutes = 1; ttkId = $ttk; description = "dep" }) }
Verif "depassement du plafond refuse (422)" ($r.Statut -eq 422)

# 7. Astreinte resolue sans explication refusee
$r = Api PUT "/api/saisies/jour/$iso" @{ jeton = $jeton; lignes = @(@{ rubrique = "ASTREINTE"; dureeMinutes = 60; description = "x"; changeOuMotif = "CHG1"; estResolu = $true }) }
Verif "astreinte resolue sans explication refusee (422)" ($r.Statut -eq 422)

# 8. Gel M+1 : jour a -2 mois refuse
$vieux = (Get-Date).AddMonths(-2).ToString("yyyy-MM-dd")
$r = Api PUT "/api/saisies/jour/$vieux" @{ jeton = $null; lignes = @($ligne) }
Verif "journee gelee refusee (GEL_PERIODE)" ($r.Statut -eq 422 -and $r.Corps.code -eq "GEL_PERIODE")

# 9. Jeton perime : conflit de concurrence
$r = Api PUT "/api/saisies/jour/$iso" @{ jeton = 1; lignes = @($ligne) }
Verif "jeton perime -> conflit (409)" ($r.Statut -eq 409)

# 10. Lot week-end (astreinte) puis suppression de la serie
$samedi = Get-Date
while ($samedi.DayOfWeek -ne "Saturday") { $samedi = $samedi.AddDays(-1) }
$dimanche = $samedi.AddDays(1)
$r = Api POST "/api/saisies/lot" @{
    jours = @($samedi.ToString("yyyy-MM-dd"), $dimanche.ToString("yyyy-MM-dd"))
    ligne = @{ rubrique = "ASTREINTE"; dureeMinutes = 60; description = "Test integration serie"; changeOuMotif = "Astreinte test"; estResolu = $false }
}
Verif "lot astreinte week-end cree (serie)" ($r.Statut -eq 200 -and $r.Corps.crees.Count -eq 2 -and $r.Corps.groupeId)
$serie = $r.Corps.groupeId
$r = Api DELETE "/api/saisies/series/$serie" $null
Verif "serie supprimee" ($r.Statut -eq 200 -and $r.Corps.supprimes -eq 2)

# 11. Nettoyage : journee de test remise a vide
$r = Api GET "/api/saisies?du=$iso&au=$iso" $null
$jetonActuel = $r.Corps.jetons.$iso
$r = Api PUT "/api/saisies/jour/$iso" @{ jeton = $jetonActuel; lignes = @() }
Verif "nettoyage de la journee de test" ($r.Statut -eq 200)

Write-Host ""
Write-Host ("{0}/{1} verifications OK" -f ($nb - $ko), $nb)
if ($ko -gt 0) { exit 1 } else { exit 0 }
