# CRA - construction SANS INSTALLER le SDK .NET.
# A lancer sur un poste Windows avec internet, PowerShell (5.1 ou 7), sans droits admin.
# Le SDK est telecharge en archive zip, decompresse dans un dossier utilisateur,
# utilise pour construire, et n'est PAS installe (rien dans Programmes, aucun
# changement systeme). Relancable : le SDK decompresse est reutilise.
# Usage :
#   powershell -ExecutionPolicy Bypass -File .\construire-sans-installation.ps1
#   ... -Nettoyer   pour supprimer le SDK decompresse a la fin (~800 Mo recuperes)
param(
    [switch]$Nettoyer
)
$ErrorActionPreference = "Stop"
$ici = Split-Path -Parent $MyInvocation.MyCommand.Path

# 1. Trouver ou obtenir un SDK utilisable
$dotnet = $null
$cmd = Get-Command dotnet -ErrorAction SilentlyContinue
if ($cmd) {
    $sdks = & $cmd.Source --list-sdks 2>$null
    if ($sdks -match "^1[0-9]\.") { $dotnet = $cmd.Source; Write-Host "SDK .NET deja present, utilise tel quel." }
}
$dossierSdk = Join-Path $env:LOCALAPPDATA "cra-sdk"
if (-not $dotnet) {
    $dotnetLocal = Join-Path $dossierSdk "dotnet.exe"
    if (Test-Path $dotnetLocal) {
        $dotnet = $dotnetLocal
        Write-Host "SDK decompresse lors d'une precedente execution, reutilise : $dossierSdk"
    } else {
        $zip = Join-Path $env:TEMP "dotnet-sdk-win-x64.zip"
        Write-Host "Telechargement du SDK .NET 10 (archive zip officielle Microsoft, ~300 Mo)..."
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest "https://aka.ms/dotnet/10.0/dotnet-sdk-win-x64.zip" -OutFile $zip -UseBasicParsing
        Write-Host "Decompression dans $dossierSdk (dossier utilisateur, rien d'installe)..."
        New-Item -ItemType Directory -Path $dossierSdk -Force | Out-Null
        Expand-Archive -Path $zip -DestinationPath $dossierSdk -Force
        Remove-Item $zip -Force
        $dotnet = $dotnetLocal
    }
    $env:DOTNET_ROOT = $dossierSdk
    $env:PATH = "$dossierSdk;$env:PATH"
}
$env:DOTNET_CLI_TELEMETRY_OPTOUT = "1"
$env:DOTNET_NOLOGO = "1"

# 2. Tests unitaires (le script s'arrete au premier echec)
Write-Host ""
Write-Host "Tests unitaires des regles metier..."
& $dotnet run --project (Join-Path $ici "Cra.Tests") -c Release
if ($LASTEXITCODE -ne 0) { throw "Echec des tests : construction abandonnee." }

# 3. Publication (le pilote SQL officiel est fourni dans pilotes\, pas de NuGet requis)
Write-Host ""
Write-Host "Publication de l'application..."
$sortie = Join-Path $ici "publication"
& $dotnet publish (Join-Path $ici "Cra.Web") -c Release -p:PilotesLocaux=true -p:PiloteOs=win -o $sortie
if ($LASTEXITCODE -ne 0) { throw "Echec de la publication." }
if (-not (Test-Path (Join-Path $sortie "Cra.Web.dll"))) { throw "Publication incomplete (Cra.Web.dll absent)." }

# 4. Nettoyage optionnel du SDK decompresse
if ($Nettoyer -and (Test-Path $dossierSdk)) {
    Remove-Item $dossierSdk -Recurse -Force
    Write-Host "SDK decompresse supprime ($dossierSdk)."
}

Write-Host ""
Write-Host "Termine. Dossier a copier sur le serveur : $sortie"
Write-Host "Ensuite, sur le serveur :  .\deployer-app.ps1 -Source C:\cra\publication"
