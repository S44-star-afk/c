# CRA - deploiement de l'application sur le serveur (PowerShell ADMINISTRATEUR).
# Usage : .\deployer-app.ps1 -Source C:\chemin\publication
param(
    [Parameter(Mandatory = $true)][string]$Source,
    [string]$Destination = "C:\inetpub\cra",
    [string]$Site = "CRA",
    [string]$Pool = "CRA"
)
$ErrorActionPreference = "Stop"

if (-not (Test-Path (Join-Path $Source "Cra.Web.dll"))) {
    throw "Dossier de publication invalide (Cra.Web.dll absent) : $Source"
}
Import-Module WebAdministration

$aEnv = [bool][Environment]::GetEnvironmentVariable("CRA_CONNEXION", "Machine")
$aFichier = Test-Path (Join-Path $Destination "configuration.json")
if (-not $aEnv -and -not $aFichier) {
    Write-Warning "Aucune configuration trouvee (ni variable CRA_CONNEXION, ni configuration.json) : l'application ne demarrera pas. Cf CONNECTEURS.txt partie 4."
}

# Pool dedie sans runtime managé IIS (le module ASP.NET Core lance le processus .NET)
if (-not (Test-Path "IIS:\AppPools\$Pool")) { New-WebAppPool -Name $Pool | Out-Null }
Set-ItemProperty "IIS:\AppPools\$Pool" managedRuntimeVersion ""

# Sauvegarde de la version en place, arret, copie
if (Test-Path $Destination) {
    $horodatage = Get-Date -Format "yyyyMMdd-HHmmss"
    Copy-Item $Destination "$Destination.avant-$horodatage" -Recurse
    Write-Host "Version precedente conservee : $Destination.avant-$horodatage"
}
Stop-WebAppPool -Name $Pool -ErrorAction SilentlyContinue
Stop-Website -Name $Site -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $Destination -Force | Out-Null

# Le fichier de configuration local (configuration.json) est PRESERVE lors des mises a jour
$configLocale = Join-Path $Destination "configuration.json"
$configTemporaire = $null
if (Test-Path $configLocale) {
    $configTemporaire = [IO.Path]::GetTempFileName()
    Copy-Item $configLocale $configTemporaire -Force
}
Copy-Item (Join-Path $Source "*") $Destination -Recurse -Force
if ($configTemporaire) {
    Copy-Item $configTemporaire $configLocale -Force
    Remove-Item $configTemporaire -Force
    Write-Host "configuration.json existant preserve."
}

# Site
if (-not (Test-Path "IIS:\Sites\$Site")) {
    Stop-Website "Default Web Site" -ErrorAction SilentlyContinue
    New-Website -Name $Site -Port 80 -PhysicalPath $Destination -ApplicationPool $Pool | Out-Null
} else {
    Set-ItemProperty "IIS:\Sites\$Site" -Name applicationPool -Value $Pool
    Set-ItemProperty "IIS:\Sites\$Site" -Name physicalPath -Value $Destination
}
Start-WebAppPool -Name $Pool
Start-Website -Name $Site
Start-Sleep -Seconds 3

try {
    $r = Invoke-RestMethod "http://localhost/sante"
    Write-Host ("Deploye. /sante -> " + $r.statut)
    if ($r.statut -ne "OK") {
        Write-Warning "Base injoignable : verifier CRA_CONNEXION puis 'Restart-WebAppPool $Pool'."
    }
} catch {
    Write-Warning "Le site ne repond pas : verifier que le .NET Hosting Bundle est installe (module AspNetCoreModuleV2) et consulter les journaux."
}
