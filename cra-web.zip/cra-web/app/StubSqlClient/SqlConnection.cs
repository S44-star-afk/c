// STUB DE COMPILATION UNIQUEMENT - jamais livré, jamais exécuté.
// Permet de compiler et d'analyser Cra.Web dans un environnement sans accès
// au registre NuGet. La construction réelle (construire.ps1) référence le
// paquet officiel Microsoft.Data.SqlClient et n'inclut PAS ce projet.
using System.Data;
using System.Data.Common;

namespace Microsoft.Data.SqlClient;

public sealed class SqlConnection : DbConnection
{
    public SqlConnection(string connectionString) => ConnectionString = connectionString;

    [System.Diagnostics.CodeAnalysis.AllowNull]
    public override string ConnectionString { get; set; } = "";
    public override string Database => throw new NotSupportedException("stub");
    public override string DataSource => throw new NotSupportedException("stub");
    public override string ServerVersion => throw new NotSupportedException("stub");
    public override ConnectionState State => ConnectionState.Closed;

    public override void ChangeDatabase(string databaseName) => throw new NotSupportedException("stub");
    public override void Close() { }
    public override void Open() => throw new NotSupportedException("stub : construction réelle requise (construire.ps1).");
    protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel) => throw new NotSupportedException("stub");
    protected override DbCommand CreateDbCommand() => throw new NotSupportedException("stub");
}
