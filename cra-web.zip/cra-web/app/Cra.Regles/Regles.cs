namespace Cra.Regles;

/// <summary>
/// Moteur de règles métier du CRA. Pur (aucune dépendance, aucune E/S) :
/// c'est la traduction exacte des règles validées avec la maquette
/// (R1 plafond 450, R2 gel M+1, R7 fenêtre manager, R8 astreinte,
/// R9 saisie en lot, R10 mots de passe). Testé par Cra.Tests.
/// </summary>
public static class Rubriques
{
    public const string Normale = "NORMALE";
    public const string Hno = "HNO";
    public const string Astreinte = "ASTREINTE";
    public static readonly string[] Toutes = { Normale, Hno, Astreinte };
}

/// <summary>Une ligne de saisie telle que soumise par le client (avant persistance).</summary>
public sealed record LigneSaisie(
    string Rubrique,
    int DureeMinutes,
    int? TtkId,
    int? ProjetId,
    string? Description,
    string? ChangeOuMotif,
    bool? EstResolu,
    string? ResolutionCommentaire);

public static class MoteurRegles
{
    // ----- R2 / H4 : fenêtre de modification glissante -----

    /// <summary>Ajoute n mois calendaires, quantième bloqué au dernier jour du mois d'arrivée (31/01 -> 28/02).</summary>
    public static DateOnly AjouterMoisClamp(DateOnly jour, int mois)
    {
        var cible = new DateOnly(jour.Year, jour.Month, 1).AddMonths(mois);
        var dernier = DateTime.DaysInMonth(cible.Year, cible.Month);
        return new DateOnly(cible.Year, cible.Month, Math.Min(jour.Day, dernier));
    }

    /// <summary>Dernier jour (inclus) où la journée reste modifiable par son propriétaire.</summary>
    public static DateOnly LimiteModification(DateOnly jour, int fenetreMois)
        => AjouterMoisClamp(jour, fenetreMois);

    /// <summary>R2 : le technicien peut écrire tant que aujourd'hui &lt;= limite.</summary>
    public static bool TechnicienPeutModifier(DateOnly jour, DateOnly aujourdhui, int fenetreMois)
        => aujourdhui <= LimiteModification(jour, fenetreMois);

    /// <summary>R7 : le manager n'intervient que sur le mois calendaire en cours.</summary>
    public static bool ManagerPeutModifier(DateOnly jour, DateOnly aujourdhui)
        => jour.Year == aujourdhui.Year && jour.Month == aujourdhui.Month;

    // ----- Calendrier -----

    public static bool EstWeekend(DateOnly jour)
        => jour.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday;

    public static bool EstJourOuvre(DateOnly jour, IReadOnlySet<DateOnly> feries)
        => !EstWeekend(jour) && !feries.Contains(jour);

    // ----- Validation des lignes -----

    /// <summary>Validation des champs d'une ligne, hors contexte du jour (partagée saisie unitaire / lot).</summary>
    public static List<string> ErreursChampsLigne(LigneSaisie l, string prefixe = "")
    {
        var erreurs = new List<string>();
        if (!Rubriques.Toutes.Contains(l.Rubrique))
        {
            erreurs.Add(prefixe + "rubrique inconnue.");
            return erreurs; // les autres contrôles n'ont pas de sens
        }
        if (l.DureeMinutes < 1 || l.DureeMinutes > 1440)
        {
            erreurs.Add(prefixe + "durée invalide (entier de 1 à 1440 minutes).");
        }
        if (string.IsNullOrWhiteSpace(l.Description))
        {
            erreurs.Add(prefixe + "la description est obligatoire.");
        }
        if (l.Rubrique == Rubriques.Normale && l.TtkId is null)
        {
            erreurs.Add(prefixe + "le TTK est obligatoire en activité normale.");
        }
        if (l.Rubrique == Rubriques.Astreinte)
        {
            if (string.IsNullOrWhiteSpace(l.ChangeOuMotif))
            {
                erreurs.Add(prefixe + "le n° de change ou le motif est obligatoire.");
            }
            if (l.EstResolu is null)
            {
                erreurs.Add(prefixe + "indiquer si l'intervention est résolue (Oui/Non).");
            }
            if (l.EstResolu == true && string.IsNullOrWhiteSpace(l.ResolutionCommentaire))
            {
                erreurs.Add(prefixe + "explication de résolution obligatoire lorsque « Résolu = Oui ».");
            }
            if (l.EstResolu == false && !string.IsNullOrWhiteSpace(l.ResolutionCommentaire))
            {
                erreurs.Add(prefixe + "pas d'explication à saisir lorsque « Résolu = Non ».");
            }
        }
        else
        {
            // Les champs d'astreinte sont interdits sur les autres rubriques (miroir des CHECK SQL).
            if (l.ChangeOuMotif is not null || l.EstResolu is not null || l.ResolutionCommentaire is not null)
            {
                erreurs.Add(prefixe + "champs d'astreinte présents sur une rubrique non astreinte.");
            }
        }
        return erreurs;
    }

    /// <summary>R1 + rubrique/jour : validation d'un ensemble de lignes formant une journée.</summary>
    public static List<string> ValiderLignesJour(
        DateOnly jour, IReadOnlyList<LigneSaisie> lignes, IReadOnlySet<DateOnly> feries, int minutesCible)
    {
        var erreurs = new List<string>();
        var totalNormale = 0;
        for (var i = 0; i < lignes.Count; i++)
        {
            var l = lignes[i];
            var prefixe = $"Ligne {i + 1} ({l.Rubrique}) : ";
            erreurs.AddRange(ErreursChampsLigne(l, prefixe));
            if (l.Rubrique == Rubriques.Normale)
            {
                totalNormale += l.DureeMinutes;
                if (!EstJourOuvre(jour, feries))
                {
                    erreurs.Add(prefixe + "l'activité normale est réservée aux jours ouvrés — utilisez HNO ou Astreinte.");
                }
            }
        }
        if (totalNormale > minutesCible)
        {
            erreurs.Add($"Le total NORMALE ({totalNormale} min) dépasse l'objectif de {minutesCible} min — basculez le dépassement en HNO.");
        }
        return erreurs;
    }

    // ----- R9 : saisie en lot -----

    /// <summary>Motif de refus d'UN jour pour une ligne commune (null = accepté). Création partielle avec rapport.</summary>
    public static string? MotifRefusJourLot(
        DateOnly jour, LigneSaisie ligne, int minutesNormalesExistantes,
        DateOnly aujourdhui, int fenetreMois, IReadOnlySet<DateOnly> feries, int minutesCible)
    {
        if (!TechnicienPeutModifier(jour, aujourdhui, fenetreMois))
        {
            return "journée verrouillée (fenêtre M+1 dépassée)";
        }
        if (ligne.Rubrique == Rubriques.Normale)
        {
            if (!EstJourOuvre(jour, feries))
            {
                return feries.Contains(jour) ? "jour férié" : "week-end";
            }
            if (minutesNormalesExistantes + ligne.DureeMinutes > minutesCible)
            {
                return $"dépasserait {minutesCible} min (déjà {minutesNormalesExistantes} min saisies)";
            }
        }
        return null;
    }

    // ----- R10 : mots de passe -----

    public static string? ValiderMotDePasse(string? mdp)
        => string.IsNullOrEmpty(mdp) || mdp.Trim().Length < 12
            ? "Le mot de passe doit compter au moins 12 caractères."
            : null;
}
