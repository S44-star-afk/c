# CRA - construction de l'application (a lancer sur un poste AVEC internet).
# Produit le dossier .\publication a copier sur le serveur (voir APPLICATION.txt).
# Prerequis : SDK .NET 10 (winget install Microsoft.DotNet.SDK.10, ou site Microsoft).
param([string]$Sortie = "publication")
$ErrorActionPreference = "Stop"

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw "SDK .NET introuvable. Installer le SDK .NET 10 puis relancer."
}

Write-Host "1/3 Tests unitaires du moteur de regles"
dotnet run --project Cra.Tests -c Release
if ($LASTEXITCODE -ne 0) { throw "Tests unitaires en echec - construction interrompue." }

Write-Host "2/3 Publication de l'application (telechargement du pilote SQL via NuGet)"
dotnet publish Cra.Web -c Release -o $Sortie
if ($LASTEXITCODE -ne 0) { throw "Echec de publication." }

Write-Host "3/3 Termine."
Write-Host "Copier le dossier '$Sortie' sur le serveur puis suivre APPLICATION.txt (partie 3)."
