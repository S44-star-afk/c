// Tests unitaires du moteur de règles (mêmes cas que la maquette validée).
// Exécution : dotnet run --project Cra.Tests   -> code retour 0 si tout passe.
using Cra.Regles;

var nb = 0;
var ko = 0;

void Attendre(string libelle, object? obtenu, object? voulu)
{
    nb++;
    var ok = Equals(obtenu, voulu);
    if (!ok)
    {
        ko++;
        Console.WriteLine($"ECHEC {libelle} : obtenu [{obtenu}], attendu [{voulu}]");
    }
    else
    {
        Console.WriteLine($"OK  {libelle}");
    }
}

DateOnly J(string iso) => DateOnly.Parse(iso);
var feries = new HashSet<DateOnly> { J("2026-07-14"), J("2026-08-15"), J("2026-11-11") };

// ----- Gel M+1 (R2/H4), quantième bloqué en fin de mois -----
Attendre("31/01/2026 + 1 mois -> 28/02/2026", MoteurRegles.AjouterMoisClamp(J("2026-01-31"), 1), J("2026-02-28"));
Attendre("31/01/2024 + 1 mois -> 29/02/2024 (bissextile)", MoteurRegles.AjouterMoisClamp(J("2024-01-31"), 1), J("2024-02-29"));
Attendre("31/03/2026 + 1 mois -> 30/04/2026", MoteurRegles.AjouterMoisClamp(J("2026-03-31"), 1), J("2026-04-30"));
Attendre("05/07/2026 + 1 mois -> 05/08/2026", MoteurRegles.AjouterMoisClamp(J("2026-07-05"), 1), J("2026-08-05"));

Attendre("technicien : 05/07 modifiable le 05/08 (dernier jour)", MoteurRegles.TechnicienPeutModifier(J("2026-07-05"), J("2026-08-05"), 1), true);
Attendre("technicien : 05/07 gelée le 06/08", MoteurRegles.TechnicienPeutModifier(J("2026-07-05"), J("2026-08-06"), 1), false);
Attendre("technicien : 04/07 gelée le 05/08", MoteurRegles.TechnicienPeutModifier(J("2026-07-04"), J("2026-08-05"), 1), false);
Attendre("technicien : 06/07 modifiable le 05/08", MoteurRegles.TechnicienPeutModifier(J("2026-07-06"), J("2026-08-05"), 1), true);
Attendre("fenêtre paramétrable : 2 mois", MoteurRegles.TechnicienPeutModifier(J("2026-06-05"), J("2026-08-05"), 2), true);

// ----- R7 : manager limité au mois calendaire en cours -----
Attendre("manager : 01/08 modifiable le 05/08", MoteurRegles.ManagerPeutModifier(J("2026-08-01"), J("2026-08-05")), true);
Attendre("manager : 31/08 modifiable le 05/08", MoteurRegles.ManagerPeutModifier(J("2026-08-31"), J("2026-08-05")), true);
Attendre("manager : 31/07 refusé le 05/08", MoteurRegles.ManagerPeutModifier(J("2026-07-31"), J("2026-08-05")), false);
Attendre("manager : bascule au 1er du mois", MoteurRegles.ManagerPeutModifier(J("2026-08-31"), J("2026-09-01")), false);

// ----- Jours ouvrés -----
Attendre("15/08/2026 (samedi + férié) non ouvré", MoteurRegles.EstJourOuvre(J("2026-08-15"), feries), false);
Attendre("14/07/2026 (mardi férié) non ouvré", MoteurRegles.EstJourOuvre(J("2026-07-14"), feries), false);
Attendre("14/08/2026 (vendredi) ouvré", MoteurRegles.EstJourOuvre(J("2026-08-14"), feries), true);
Attendre("08/08/2026 (samedi) non ouvré", MoteurRegles.EstJourOuvre(J("2026-08-08"), feries), false);

// ----- R1 : plafond 450 -----
LigneSaisie Normale(int duree, int? ttk = 1) => new(Rubriques.Normale, duree, ttk, null, "x", null, null, null);
Attendre("450 exactement accepté",
    MoteurRegles.ValiderLignesJour(J("2026-08-04"), new[] { Normale(225), Normale(225) }, feries, 450).Count, 0);
Attendre("451 refusé (dépassement)",
    MoteurRegles.ValiderLignesJour(J("2026-08-04"), new[] { Normale(226), Normale(225) }, feries, 450).Count > 0, true);
Attendre("NORMALE sans TTK refusée",
    MoteurRegles.ValiderLignesJour(J("2026-08-04"), new[] { Normale(100, null) }, feries, 450).Count > 0, true);
Attendre("NORMALE un samedi refusée",
    MoteurRegles.ValiderLignesJour(J("2026-08-08"), new[] { Normale(100) }, feries, 450).Count > 0, true);
Attendre("HNO un samedi acceptée",
    MoteurRegles.ValiderLignesJour(J("2026-08-08"),
        new[] { new LigneSaisie(Rubriques.Hno, 120, null, null, "x", null, null, null) }, feries, 450).Count, 0);
Attendre("durée 1441 refusée",
    MoteurRegles.ErreursChampsLigne(Normale(1441)).Count > 0, true);
Attendre("description vide refusée",
    MoteurRegles.ErreursChampsLigne(new LigneSaisie(Rubriques.Normale, 60, 1, null, "  ", null, null, null)).Count > 0, true);
Attendre("rubrique inconnue refusée",
    MoteurRegles.ErreursChampsLigne(new LigneSaisie("AUTRE", 60, null, null, "x", null, null, null)).Count > 0, true);

// ----- R8 : astreinte -----
LigneSaisie Astreinte(bool? resolu, string? commentaire, string? change = "CHG1") =>
    new(Rubriques.Astreinte, 60, null, null, "x", change, resolu, commentaire);
Attendre("astreinte résolue avec explication acceptée", MoteurRegles.ErreursChampsLigne(Astreinte(true, "ok")).Count, 0);
Attendre("astreinte résolue SANS explication refusée", MoteurRegles.ErreursChampsLigne(Astreinte(true, null)).Count > 0, true);
Attendre("astreinte non résolue sans rien acceptée", MoteurRegles.ErreursChampsLigne(Astreinte(false, null)).Count, 0);
Attendre("astreinte non résolue AVEC explication refusée", MoteurRegles.ErreursChampsLigne(Astreinte(false, "?")).Count > 0, true);
Attendre("astreinte sans change/motif refusée", MoteurRegles.ErreursChampsLigne(Astreinte(false, null, "  ")).Count > 0, true);
Attendre("astreinte sans décision refusée", MoteurRegles.ErreursChampsLigne(Astreinte(null, null)).Count > 0, true);
Attendre("champs astreinte interdits sur NORMALE",
    MoteurRegles.ErreursChampsLigne(new LigneSaisie(Rubriques.Normale, 60, 1, null, "x", "CHG1", null, null)).Count > 0, true);

// ----- R9 : lot -----
var lotNormale = Normale(200);
var lotAstreinte = Astreinte(false, null);
Attendre("lot : jour gelé refusé",
    MoteurRegles.MotifRefusJourLot(J("2026-07-04"), lotAstreinte, 0, J("2026-08-05"), 1, feries, 450) is not null, true);
Attendre("lot : astreinte un samedi acceptée",
    MoteurRegles.MotifRefusJourLot(J("2026-08-08"), lotAstreinte, 0, J("2026-08-05"), 1, feries, 450), null);
Attendre("lot : NORMALE un samedi refusée (week-end)",
    MoteurRegles.MotifRefusJourLot(J("2026-08-08"), lotNormale, 0, J("2026-08-05"), 1, feries, 450), "week-end");
Attendre("lot : NORMALE un férié refusée",
    MoteurRegles.MotifRefusJourLot(J("2026-07-14"), lotNormale, 0, J("2026-07-20"), 1, feries, 450), "jour férié");
Attendre("lot : 200 min sur jour à 300 refusée",
    MoteurRegles.MotifRefusJourLot(J("2026-08-04"), lotNormale, 300, J("2026-08-05"), 1, feries, 450) is not null, true);
Attendre("lot : 200 min sur jour à 250 acceptée (= 450)",
    MoteurRegles.MotifRefusJourLot(J("2026-08-04"), lotNormale, 250, J("2026-08-05"), 1, feries, 450), null);

// ----- R10 : mots de passe -----
Attendre("mdp : 11 caractères refusé", MoteurRegles.ValiderMotDePasse("abcdefghijk") is not null, true);
Attendre("mdp : 12 caractères accepté", MoteurRegles.ValiderMotDePasse("abcdefghijk9"), null);
Attendre("mdp : espaces seuls refusés", MoteurRegles.ValiderMotDePasse("                ") is not null, true);
Attendre("mdp : vide refusé", MoteurRegles.ValiderMotDePasse("") is not null, true);

Console.WriteLine($"\n{nb - ko}/{nb} tests OK" + (ko > 0 ? $" - {ko} ECHEC(S)" : ""));
return ko == 0 ? 0 : 1;
