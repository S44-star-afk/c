// API de saisie (perimetre technicien - increment 1).
// Toutes les regles sont appliquees ici, cote serveur, dans des transactions :
// l'identifiant du proprietaire vient TOUJOURS de la session, jamais de la requete.
using System.Data.Common;
using Cra.Regles;

namespace Cra.Web;

internal static class ApiSaisies
{
    private sealed record LigneDto(
        long? Id, string? Rubrique, int? DureeMinutes, int? TtkId, int? ProjetId,
        string? Description, string? ChangeOuMotif, bool? EstResolu, string? ResolutionCommentaire,
        string? GroupeId);

    private sealed record DemandeJour(long? Jeton, List<LigneDto>? Lignes);
    private sealed record DemandeLot(List<string>? Jours, LigneDto? Ligne);

    public static void Enregistrer(WebApplication app)
    {
        var groupe = app.MapGroup("/api").RequireAuthorization();

        // ---- Lecture des saisies de l'utilisateur connecte sur une periode ----
        groupe.MapGet("/saisies", async (HttpContext ctx, string du, string au, CancellationToken ct) =>
        {
            if (!DateOnly.TryParse(du, out var dDu) || !DateOnly.TryParse(au, out var dAu) || dAu < dDu)
            {
                return Http.Erreur(ctx, 400, "DATE_INVALIDE", "Periode invalide.");
            }
            var uid = ctx.IdUtilisateur();
            await using var cnx = await Bd.OuvrirAsync(ct);
            var lignes = await LireLignesAsync(cnx, uid, dDu, dAu, ct);
            var jetons = await JetonsParJourAsync(cnx, uid, dDu, dAu, ct);
            return Results.Json(new { lignes, jetons });
        });

        // ---- Agregats du calendrier mensuel ----
        groupe.MapGet("/calendrier/{annee:int}/{mois:int}", async (HttpContext ctx, int annee, int mois, CancellationToken ct) =>
        {
            if (mois is < 1 or > 12 || annee is < 2000 or > 2100)
            {
                return Http.Erreur(ctx, 400, "DATE_INVALIDE", "Mois invalide.");
            }
            var uid = ctx.IdUtilisateur();
            var debut = new DateOnly(annee, mois, 1);
            var fin = debut.AddMonths(1).AddDays(-1);
            await using var cnx = await Bd.OuvrirAsync(ct);
            var jours = await cnx.Commande(
                @"SELECT date_activite,
                         SUM(CASE WHEN rubrique = 'NORMALE' THEN duree_minutes ELSE 0 END),
                         SUM(CASE WHEN rubrique = 'HNO' THEN 1 ELSE 0 END),
                         SUM(CASE WHEN rubrique = 'ASTREINTE' THEN 1 ELSE 0 END)
                  FROM dbo.saisie_activite
                  WHERE utilisateur_id = @uid AND est_supprime = 0
                    AND date_activite BETWEEN @du AND @au
                  GROUP BY date_activite;")
                .Param("@uid", uid)
                .Param("@du", debut.ToDateTime(TimeOnly.MinValue))
                .Param("@au", fin.ToDateTime(TimeOnly.MinValue))
                .LireAsync(l => new
                {
                    date = DateOnly.FromDateTime(l.GetDateTime(0)).ToString("yyyy-MM-dd"),
                    minutesNormale = l.GetInt32(1),
                    nbHno = l.GetInt32(2),
                    nbAstreinte = l.GetInt32(3)
                }, ct);
            return Results.Json(new { jours });
        });

        // ---- Enregistrement d'une journee complete (tout ou rien) ----
        groupe.MapPut("/saisies/jour/{date}", async (HttpContext ctx, string date, DemandeJour d, CancellationToken ct) =>
        {
            if (!DateOnly.TryParse(date, out var jour))
            {
                return Http.Erreur(ctx, 400, "DATE_INVALIDE", "Date invalide.");
            }
            if (!ctx.ARole("TECHNICIEN"))
            {
                return Http.Erreur(ctx, 403, "DROIT_INSUFFISANT", "Reserve au technicien (increment 1).");
            }
            var uid = ctx.IdUtilisateur();
            var aujourdHui = DateOnly.FromDateTime(DateTime.Now);
            var dtoLignes = d.Lignes ?? new List<LigneDto>();

            await using var cnx = await Bd.OuvrirAsync(ct);
            var (feries, cible, fenetre) = await ContexteReglesAsync(cnx, ct);

            if (!MoteurRegles.TechnicienPeutModifier(jour, aujourdHui, fenetre))
            {
                throw new RegleException("GEL_PERIODE",
                    $"La journee du {jour:dd/MM/yyyy} n'est plus modifiable (verrouillee depuis le " +
                    $"{MoteurRegles.LimiteModification(jour, fenetre).AddDays(1):dd/MM/yyyy}).");
            }

            var lignes = dtoLignes.Select(VersLigneMetier).ToList();
            var erreurs = MoteurRegles.ValiderLignesJour(jour, lignes, feries, cible);
            if (erreurs.Count > 0)
            {
                throw new RegleException("VALIDATION", "Enregistrement refuse.", erreurs);
            }
            await VerifierTtksActifsAsync(cnx, dtoLignes, ct);

            await using var tx = await cnx.BeginTransactionAsync(ct);
            await Bd.VerrouAsync(cnx, tx, $"saisie:{uid}:{jour:yyyy-MM-dd}", ct);

            var jetonActuel = await JetonJourAsync(cnx, tx, uid, jour, ct);
            if (d.Jeton is not null && d.Jeton != jetonActuel)
            {
                throw new ConflitException(
                    "Cette journee a ete modifiee ailleurs (autre onglet ?). Rechargez avant d'enregistrer.",
                    "CONFLIT_VERSION");
            }

            var avant = await LireLignesAsync(cnx, uid, jour, jour, ct, tx);
            await cnx.Commande(
                @"UPDATE dbo.saisie_activite SET est_supprime = 1, modifie_le = SYSUTCDATETIME(), modifie_par = @uid
                  WHERE utilisateur_id = @uid AND date_activite = @jour AND est_supprime = 0;", tx)
                .Param("@uid", uid).Param("@jour", jour.ToDateTime(TimeOnly.MinValue)).ExecAsync(ct);
            foreach (var l in dtoLignes)
            {
                await InsererLigneAsync(cnx, tx, uid, jour, l, ct);
            }
            await Audit.EcrireAsync(cnx, tx, uid, "MODIF_SAISIE", "saisie_activite", null,
                new { jour = jour.ToString("yyyy-MM-dd"), lignes = avant },
                new { jour = jour.ToString("yyyy-MM-dd"), lignes = dtoLignes },
                null, ctx, ct);
            await tx.CommitAsync(ct);

            var apres = await LireLignesAsync(cnx, uid, jour, jour, ct);
            var jeton = await JetonJourAsync(cnx, null, uid, jour, ct);
            return Results.Json(new { lignes = apres, jeton });
        });

        // ---- R9 : saisie en lot (astreinte multi-jours, recurrences) ----
        groupe.MapPost("/saisies/lot", async (HttpContext ctx, DemandeLot d, CancellationToken ct) =>
        {
            if (!ctx.ARole("TECHNICIEN"))
            {
                return Http.Erreur(ctx, 403, "DROIT_INSUFFISANT", "Reserve au technicien (increment 1).");
            }
            if (d.Ligne is null || d.Jours is null || d.Jours.Count == 0 || d.Jours.Count > 400)
            {
                return Http.Erreur(ctx, 400, "CHAMP_REQUIS", "Jours et ligne requis (400 jours maximum).");
            }
            var jours = new List<DateOnly>();
            foreach (var j in d.Jours)
            {
                if (!DateOnly.TryParse(j, out var dj))
                {
                    return Http.Erreur(ctx, 400, "DATE_INVALIDE", $"Date invalide : {j}");
                }
                jours.Add(dj);
            }
            jours = jours.Distinct().OrderBy(x => x).ToList();

            var uid = ctx.IdUtilisateur();
            var aujourdHui = DateOnly.FromDateTime(DateTime.Now);
            var ligne = VersLigneMetier(d.Ligne);

            await using var cnx = await Bd.OuvrirAsync(ct);
            var (feries, cible, fenetre) = await ContexteReglesAsync(cnx, ct);
            var champs = MoteurRegles.ErreursChampsLigne(ligne);
            if (champs.Count > 0)
            {
                throw new RegleException("VALIDATION", "Lot refuse.", champs);
            }
            await VerifierTtksActifsAsync(cnx, new[] { d.Ligne }, ct);

            var groupeId = jours.Count > 1 ? (Guid?)Guid.NewGuid() : null;
            var crees = new List<string>();
            var refuses = new List<object>();

            await using var tx = await cnx.BeginTransactionAsync(ct);
            foreach (var jour in jours)
            {
                await Bd.VerrouAsync(cnx, tx, $"saisie:{uid}:{jour:yyyy-MM-dd}", ct);
                var minutes = await cnx.Commande(
                    @"SELECT COALESCE(SUM(duree_minutes), 0) FROM dbo.saisie_activite
                      WHERE utilisateur_id = @uid AND date_activite = @jour AND rubrique = 'NORMALE' AND est_supprime = 0;", tx)
                    .Param("@uid", uid).Param("@jour", jour.ToDateTime(TimeOnly.MinValue))
                    .ScalaireAsync<int>(ct);
                var motif = MoteurRegles.MotifRefusJourLot(jour, ligne, minutes, aujourdHui, fenetre, feries, cible);
                if (motif is not null)
                {
                    refuses.Add(new { jour = jour.ToString("yyyy-MM-dd"), motif });
                    continue;
                }
                await InsererLigneAsync(cnx, tx, uid, jour, d.Ligne with { GroupeId = groupeId?.ToString() }, ct);
                crees.Add(jour.ToString("yyyy-MM-dd"));
            }
            if (crees.Count > 0)
            {
                await Audit.EcrireAsync(cnx, tx, uid, "SAISIE_LOT", "saisie_activite", null, null,
                    new { rubrique = ligne.Rubrique, crees, groupe = groupeId?.ToString() },
                    refuses.Count > 0 ? $"{refuses.Count} jour(s) refuse(s)" : null, ctx, ct);
            }
            await tx.CommitAsync(ct);
            return Results.Json(new { crees, refuses, groupeId = groupeId?.ToString() });
        });

        // ---- R9 : suppression d'une serie ----
        groupe.MapDelete("/saisies/series/{groupeId:guid}", async (HttpContext ctx, Guid groupeId, CancellationToken ct) =>
        {
            if (!ctx.ARole("TECHNICIEN"))
            {
                return Http.Erreur(ctx, 403, "DROIT_INSUFFISANT", "Reserve au technicien (increment 1).");
            }
            var uid = ctx.IdUtilisateur();
            var aujourdHui = DateOnly.FromDateTime(DateTime.Now);
            await using var cnx = await Bd.OuvrirAsync(ct);
            var (_, _, fenetre) = await ContexteReglesAsync(cnx, ct);

            var membres = await cnx.Commande(
                @"SELECT id, date_activite FROM dbo.saisie_activite
                  WHERE utilisateur_id = @uid AND groupe_saisie_id = @g AND est_supprime = 0;")
                .Param("@uid", uid).Param("@g", groupeId)
                .LireAsync(l => (Id: l.GetInt64(0), Jour: DateOnly.FromDateTime(l.GetDateTime(1))), ct);
            if (membres.Count == 0)
            {
                return Http.Erreur(ctx, 404, "INTROUVABLE", "Serie introuvable.");
            }

            var supprimables = membres.Where(m => MoteurRegles.TechnicienPeutModifier(m.Jour, aujourdHui, fenetre)).ToList();
            await using var tx = await cnx.BeginTransactionAsync(ct);
            foreach (var m in supprimables)
            {
                await cnx.Commande(
                    @"UPDATE dbo.saisie_activite SET est_supprime = 1, modifie_le = SYSUTCDATETIME(), modifie_par = @uid
                      WHERE id = @id;", tx)
                    .Param("@uid", uid).Param("@id", m.Id).ExecAsync(ct);
            }
            await Audit.EcrireAsync(cnx, tx, uid, "SUPPR_SERIE", "saisie_activite", null, null,
                new { groupe = groupeId, supprimes = supprimables.Count, conserves = membres.Count - supprimables.Count },
                null, ctx, ct);
            await tx.CommitAsync(ct);
            return Results.Json(new { supprimes = supprimables.Count, conserves = membres.Count - supprimables.Count });
        });
    }

    // ----------------------------------------------------------------- aides

    private static LigneSaisie VersLigneMetier(LigneDto d) => new(
        (d.Rubrique ?? "").Trim().ToUpperInvariant(),
        d.DureeMinutes ?? 0, d.TtkId, d.ProjetId,
        d.Description?.Trim(),
        string.IsNullOrWhiteSpace(d.ChangeOuMotif) ? null : d.ChangeOuMotif.Trim(),
        d.EstResolu,
        string.IsNullOrWhiteSpace(d.ResolutionCommentaire) ? null : d.ResolutionCommentaire.Trim());

    private static async Task<(IReadOnlySet<DateOnly> Feries, int Cible, int Fenetre)> ContexteReglesAsync(
        DbConnection cnx, CancellationToken ct)
    {
        var feries = (await cnx.Commande("SELECT date_ferie FROM dbo.jour_ferie;")
            .LireAsync(l => DateOnly.FromDateTime(l.GetDateTime(0)), ct)).ToHashSet();
        var parametres = await cnx.Commande("SELECT cle, valeur FROM dbo.parametre;")
            .LireAsync(l => (Cle: l.GetString(0), Valeur: l.GetString(1)), ct);
        int Lire(string cle, int defaut)
            => parametres.Where(p => p.Cle == cle).Select(p => int.TryParse(p.Valeur, out var v) ? v : defaut).FirstOrDefault(defaut);
        return (feries, Lire("minutes_jour_cible", 450), Lire("fenetre_modification_mois", 1));
    }

    private static async Task VerifierTtksActifsAsync(DbConnection cnx, IEnumerable<LigneDto> lignes, CancellationToken ct)
    {
        foreach (var ttkId in lignes.Where(l => l.TtkId is not null).Select(l => l.TtkId!.Value).Distinct())
        {
            var actif = await cnx.Commande("SELECT est_actif FROM dbo.ttk WHERE id = @id;")
                .Param("@id", ttkId).ScalaireAsync<bool?>(ct);
            if (actif is null) { throw new RegleException("TTK_INCONNU", $"TTK {ttkId} inconnu."); }
            if (actif == false) { throw new RegleException("TTK_INACTIF", "Ce TTK est desactive : choisissez-en un autre."); }
        }
    }

    private static async Task InsererLigneAsync(
        DbConnection cnx, DbTransaction tx, int uid, DateOnly jour, LigneDto l, CancellationToken ct)
    {
        await cnx.Commande(
            @"INSERT INTO dbo.saisie_activite
                (utilisateur_id, date_activite, rubrique, ttk_id, projet_id, description, duree_minutes,
                 change_ou_motif, est_resolu, resolution_commentaire, groupe_saisie_id, cree_par)
              VALUES (@uid, @jour, @rubrique, @ttk, @projet, @description, @duree,
                 @change, @resolu, @resolution, @groupe, @uid);", tx)
            .Param("@uid", uid)
            .Param("@jour", jour.ToDateTime(TimeOnly.MinValue))
            .Param("@rubrique", (l.Rubrique ?? "").Trim().ToUpperInvariant())
            .Param("@ttk", l.TtkId)
            .Param("@projet", l.ProjetId)
            .Param("@description", l.Description?.Trim())
            .Param("@duree", l.DureeMinutes)
            .Param("@change", string.IsNullOrWhiteSpace(l.ChangeOuMotif) ? null : l.ChangeOuMotif.Trim())
            .Param("@resolu", l.EstResolu)
            .Param("@resolution", string.IsNullOrWhiteSpace(l.ResolutionCommentaire) ? null : l.ResolutionCommentaire.Trim())
            .Param("@groupe", string.IsNullOrWhiteSpace(l.GroupeId) ? null : Guid.Parse(l.GroupeId))
            .ExecAsync(ct);
    }

    private static async Task<object> LireLignesAsync(
        DbConnection cnx, int uid, DateOnly du, DateOnly au, CancellationToken ct, DbTransaction? tx = null)
        => await cnx.Commande(
            @"SELECT id, date_activite, rubrique, ttk_id, projet_id, description, duree_minutes,
                     change_ou_motif, est_resolu, resolution_commentaire, groupe_saisie_id
              FROM dbo.saisie_activite
              WHERE utilisateur_id = @uid AND est_supprime = 0 AND date_activite BETWEEN @du AND @au
              ORDER BY date_activite, id;", tx)
            .Param("@uid", uid)
            .Param("@du", du.ToDateTime(TimeOnly.MinValue))
            .Param("@au", au.ToDateTime(TimeOnly.MinValue))
            .LireAsync(l => new
            {
                id = l.GetInt64(0),
                date = DateOnly.FromDateTime(l.GetDateTime(1)).ToString("yyyy-MM-dd"),
                rubrique = l.GetString(2),
                ttkId = l.EntierOuNull(3),
                projetId = l.EntierOuNull(4),
                description = l.GetString(5),
                dureeMinutes = (int)l.GetInt16(6),
                changeOuMotif = l.TexteOuNull(7),
                estResolu = l.BoolOuNull(8),
                resolutionCommentaire = l.TexteOuNull(9),
                groupeId = l.IsDBNull(10) ? null : l.GetGuid(10).ToString()
            }, ct);

    /// <summary>Jeton de concurrence d'une journee : MAX(version_ligne) toutes lignes confondues (0 si aucune).</summary>
    private static async Task<long> JetonJourAsync(
        DbConnection cnx, DbTransaction? tx, int uid, DateOnly jour, CancellationToken ct)
        => await cnx.Commande(
            @"SELECT COALESCE(MAX(CAST(version_ligne AS BIGINT)), 0) FROM dbo.saisie_activite
              WHERE utilisateur_id = @uid AND date_activite = @jour;", tx)
            .Param("@uid", uid).Param("@jour", jour.ToDateTime(TimeOnly.MinValue))
            .ScalaireAsync<long>(ct);

    private static async Task<Dictionary<string, long>> JetonsParJourAsync(
        DbConnection cnx, int uid, DateOnly du, DateOnly au, CancellationToken ct)
    {
        var paires = await cnx.Commande(
            @"SELECT date_activite, MAX(CAST(version_ligne AS BIGINT)) FROM dbo.saisie_activite
              WHERE utilisateur_id = @uid AND date_activite BETWEEN @du AND @au
              GROUP BY date_activite;")
            .Param("@uid", uid)
            .Param("@du", du.ToDateTime(TimeOnly.MinValue))
            .Param("@au", au.ToDateTime(TimeOnly.MinValue))
            .LireAsync(l => (Jour: DateOnly.FromDateTime(l.GetDateTime(0)).ToString("yyyy-MM-dd"), Jeton: l.GetInt64(1)), ct);
        return paires.ToDictionary(p => p.Jour, p => p.Jeton);
    }
}
