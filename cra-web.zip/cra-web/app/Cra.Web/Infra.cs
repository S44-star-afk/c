// Infrastructure : accès base (ADO.NET pur), mots de passe, audit, aides HTTP.
using System.Data;
using System.Data.Common;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.Data.SqlClient;

namespace Cra.Web;

/// <summary>Accès base : fabrique de connexions + aides ADO.NET (requêtes paramétrées uniquement).</summary>
public static class Bd
{
    public static string ChaineConnexion { get; private set; } = "";

    /// <summary>
    /// Configuration en couches : 1) variable d'environnement CRA_CONNEXION (prioritaire),
    /// 2) fichier configuration.json a cote de l'application (modele : configuration.exemple.json).
    /// Panne franche au demarrage si aucune source n'est renseignee.
    /// </summary>
    public static void Initialiser()
    {
        var chaine = Environment.GetEnvironmentVariable("CRA_CONNEXION");
        if (string.IsNullOrWhiteSpace(chaine))
        {
            var fichier = Path.Combine(AppContext.BaseDirectory, "configuration.json");
            if (File.Exists(fichier))
            {
                try
                {
                    using var doc = JsonDocument.Parse(File.ReadAllText(fichier));
                    if (doc.RootElement.TryGetProperty("chaineConnexion", out var v))
                    {
                        chaine = v.GetString();
                    }
                }
                catch (JsonException e)
                {
                    throw new InvalidOperationException($"configuration.json illisible : {e.Message}");
                }
            }
        }
        if (string.IsNullOrWhiteSpace(chaine) || chaine.Contains("A_REMPLIR"))
        {
            throw new InvalidOperationException(
                "Aucune chaine de connexion renseignee. Deux possibilites : " +
                "1) variable d'environnement machine CRA_CONNEXION (prioritaire) ; " +
                "2) fichier configuration.json a cote de l'application (copier configuration.exemple.json puis remplir). " +
                "Exemple : Server=.\\SQLEXPRESS;Database=cra;User Id=cra_app;Password=...;TrustServerCertificate=True");
        }
        ChaineConnexion = chaine;
    }

    public static async Task<DbConnection> OuvrirAsync(CancellationToken ct = default)
    {
        DbConnection cnx = new SqlConnection(ChaineConnexion);
        await cnx.OpenAsync(ct);
        return cnx;
    }

    public static DbCommand Commande(this DbConnection cnx, string sql, DbTransaction? tx = null)
    {
        var cmd = cnx.CreateCommand();
        cmd.CommandText = sql;
        if (tx is not null) { cmd.Transaction = tx; }
        return cmd;
    }

    public static DbCommand Param(this DbCommand cmd, string nom, object? valeur)
    {
        var p = cmd.CreateParameter();
        p.ParameterName = nom;
        p.Value = valeur ?? DBNull.Value;
        cmd.Parameters.Add(p);
        return cmd;
    }

    public static async Task<int> ExecAsync(this DbCommand cmd, CancellationToken ct = default)
        => await cmd.ExecuteNonQueryAsync(ct);

    public static async Task<T?> ScalaireAsync<T>(this DbCommand cmd, CancellationToken ct = default)
    {
        var r = await cmd.ExecuteScalarAsync(ct);
        if (r is null || r is DBNull) { return default; }
        return (T)Convert.ChangeType(r, typeof(T));
    }

    public static async Task<List<T>> LireAsync<T>(this DbCommand cmd, Func<DbDataReader, T> projeter, CancellationToken ct = default)
    {
        var liste = new List<T>();
        await using var lecteur = await cmd.ExecuteReaderAsync(ct);
        while (await lecteur.ReadAsync(ct)) { liste.Add(projeter(lecteur)); }
        return liste;
    }

    public static int? EntierOuNull(this DbDataReader l, int i) => l.IsDBNull(i) ? null : l.GetInt32(i);
    public static string? TexteOuNull(this DbDataReader l, int i) => l.IsDBNull(i) ? null : l.GetString(i);
    public static bool? BoolOuNull(this DbDataReader l, int i) => l.IsDBNull(i) ? null : l.GetBoolean(i);

    /// <summary>Verrou applicatif sérialisant (transaction requise). Lève en cas d'échec d'acquisition.</summary>
    public static async Task VerrouAsync(DbConnection cnx, DbTransaction tx, string ressource, CancellationToken ct)
    {
        var cmd = cnx.Commande(
            "DECLARE @r INT; EXEC @r = sp_getapplock @Resource=@ressource, @LockMode='Exclusive', @LockOwner='Transaction', @LockTimeout=5000; SELECT @r;", tx)
            .Param("@ressource", ressource);
        var resultat = await cmd.ScalaireAsync<int>(ct);
        if (resultat < 0)
        {
            throw new ConflitException("Une autre opération est en cours sur cette journée, réessayez.");
        }
    }
}

/// <summary>Erreur métier (422) transportant un code stable.</summary>
public sealed class RegleException(string code, string message, IReadOnlyList<string>? details = null) : Exception(message)
{
    public string Code { get; } = code;
    public IReadOnlyList<string> Details { get; } = details ?? Array.Empty<string>();
}

/// <summary>Conflit de concurrence ou d'état (409).</summary>
public sealed class ConflitException(string message, string code = "CONFLIT") : Exception(message)
{
    public string Code { get; } = code;
}

/// <summary>Hachage des mots de passe : PBKDF2-SHA256, 600 000 itérations (format autoportant).</summary>
public static class MotsDePasse
{
    private const int Iterations = 600_000;
    private const int TailleSel = 16;
    private const int TailleHash = 32;

    public static string Hacher(string mdp)
    {
        var sel = RandomNumberGenerator.GetBytes(TailleSel);
        var hash = Rfc2898DeriveBytes.Pbkdf2(mdp, sel, Iterations, HashAlgorithmName.SHA256, TailleHash);
        return $"PBKDF2.{Iterations}.{Convert.ToBase64String(sel)}.{Convert.ToBase64String(hash)}";
    }

    public static bool Verifier(string mdp, string haché)
    {
        var parts = haché.Split('.');
        if (parts.Length != 4 || parts[0] != "PBKDF2") { return false; }
        var iterations = int.Parse(parts[1]);
        var sel = Convert.FromBase64String(parts[2]);
        var attendu = Convert.FromBase64String(parts[3]);
        var calcule = Rfc2898DeriveBytes.Pbkdf2(mdp, sel, iterations, HashAlgorithmName.SHA256, attendu.Length);
        return CryptographicOperations.FixedTimeEquals(calcule, attendu);
    }
}

/// <summary>Écriture du journal d'audit (dans la transaction de l'opération : tout ou rien).</summary>
public static class Audit
{
    public static async Task EcrireAsync(
        DbConnection cnx, DbTransaction? tx, int? acteurId, string action,
        string? typeEntite, long? entiteId, object? avant, object? apres, string? motif,
        HttpContext? http, CancellationToken ct = default)
    {
        var cmd = cnx.Commande(
            @"INSERT INTO dbo.journal_audit
                (acteur_id, action, type_entite, entite_id, valeur_avant, valeur_apres, motif, adresse_ip, correlation_id)
              VALUES (@acteur, @action, @type, @entite, @avant, @apres, @motif, @ip, @correlation);", tx)
            .Param("@acteur", acteurId)
            .Param("@action", action)
            .Param("@type", typeEntite)
            .Param("@entite", entiteId)
            .Param("@avant", avant is null ? null : JsonSerializer.Serialize(avant))
            .Param("@apres", apres is null ? null : JsonSerializer.Serialize(apres))
            .Param("@motif", motif)
            .Param("@ip", http?.Connection.RemoteIpAddress?.ToString())
            .Param("@correlation", http?.Items["correlationId"] as Guid? ?? Guid.NewGuid());
        await cmd.ExecAsync(ct);
    }
}

/// <summary>Aides HTTP : identité de session, réponses d'erreur normalisées.</summary>
public static class Http
{
    public static int IdUtilisateur(this HttpContext ctx)
        => int.Parse(ctx.User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    public static string NomUtilisateur(this HttpContext ctx)
        => ctx.User.FindFirstValue(ClaimTypes.Name) ?? "?";

    public static bool ARole(this HttpContext ctx, string role)
        => ctx.User.IsInRole(role);

    public static IResult Erreur(HttpContext ctx, int statut, string code, string message, IReadOnlyList<string>? details = null)
        => Results.Json(new
        {
            code,
            message,
            details = details ?? Array.Empty<string>(),
            correlationId = (ctx.Items["correlationId"] as Guid?)?.ToString()
        }, statusCode: statut);
}
