// CRA - application web (increment 1 : coeur technicien).
// Hébergement : IIS (module ASP.NET Core) sur serveur1 ; base : SQL Server Express locale.
// Configuration : variable d'environnement CRA_CONNEXION (chaîne de connexion, compte cra_app).
using System.Security.Claims;
using Cra.Regles;
using Cra.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

// ---------- Pilote SQL : reseau gere (managed SNI) ----------
// La publication embarque le pilote officiel sans sa DLL native Windows (SNI) ;
// ce commutateur fait passer SqlClient par son implementation reseau 100 % .NET,
// equivalente pour notre usage (TCP local, TrustServerCertificate).
// Desactivable si un jour la DLL native est ajoutee : variable CRA_SNI_NATIF=1.
if (Environment.GetEnvironmentVariable("CRA_SNI_NATIF") != "1")
{
    AppContext.SetSwitch("Switch.Microsoft.Data.SqlClient.UseManagedNetworkingOnWindows", true);
}

// ---------- Mode outil en ligne de commande : creation du compte admin initial ----------
if (args.Length > 0 && (args[0] == "creer-admin" || args[0] == "creer-utilisateur"))
{
    return await OutilCreerAdmin.ExecuterAsync(args);
}

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(o =>
    {
        o.Cookie.Name = "cra_session";
        o.Cookie.HttpOnly = true;
        o.Cookie.SameSite = SameSiteMode.Strict;
        o.Cookie.SecurePolicy = CookieSecurePolicy.None; // decision D1 : HTTP interne
        o.SlidingExpiration = true;
        o.ExpireTimeSpan = TimeSpan.FromHours(12);
        o.Events.OnRedirectToLogin = c => { c.Response.StatusCode = 401; return Task.CompletedTask; };
        o.Events.OnRedirectToAccessDenied = c => { c.Response.StatusCode = 403; return Task.CompletedTask; };
    });
builder.Services.AddAuthorization();

var app = builder.Build();

Bd.Initialiser(); // echoue au demarrage si CRA_CONNEXION absente : panne franche plutot que site cassé

// ---------- Identifiant de correlation + erreurs normalisees ----------
app.Use(async (ctx, suite) =>
{
    var correlation = Guid.NewGuid();
    ctx.Items["correlationId"] = correlation;
    ctx.Response.Headers["X-Correlation"] = correlation.ToString();
    try
    {
        await suite();
    }
    catch (RegleException e)
    {
        ctx.Response.Clear();
        await Http.Erreur(ctx, 422, e.Code, e.Message, e.Details).ExecuteAsync(ctx);
    }
    catch (ConflitException e)
    {
        ctx.Response.Clear();
        await Http.Erreur(ctx, 409, e.Code, e.Message).ExecuteAsync(ctx);
    }
    catch (Exception e)
    {
        app.Logger.LogError(e, "Erreur technique [correlation {Correlation}]", correlation);
        ctx.Response.Clear();
        await Http.Erreur(ctx, 500, "ERREUR_TECHNIQUE",
            "Erreur interne : contactez l'administrateur en citant l'identifiant.").ExecuteAsync(ctx);
    }
});

// ---------- Garde CSRF : les ecritures exigent l'en-tete X-CRA (les navigateurs tiers ne peuvent pas l'envoyer en cross-site) ----------
app.Use(async (ctx, suite) =>
{
    var mutation = HttpMethods.IsPost(ctx.Request.Method) || HttpMethods.IsPut(ctx.Request.Method) || HttpMethods.IsDelete(ctx.Request.Method);
    if (mutation && ctx.Request.Path.StartsWithSegments("/api") && ctx.Request.Headers["X-CRA"] != "1")
    {
        await Http.Erreur(ctx, 400, "CSRF", "En-tete de protection absent.").ExecuteAsync(ctx);
        return;
    }
    await suite();
});

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();

// ---------- Surveillance ----------
app.MapGet("/sante", async (HttpContext ctx, CancellationToken ct) =>
{
    try
    {
        await using var cnx = await Bd.OuvrirAsync(ct);
        var un = await cnx.Commande("SELECT 1;").ScalaireAsync<int>(ct);
        return Results.Json(new { statut = "OK", base_de_donnees = un == 1 });
    }
    catch (Exception e)
    {
        app.Logger.LogError(e, "Sante : base injoignable");
        return Results.Json(new { statut = "DEGRADE", base_de_donnees = false }, statusCode: 503);
    }
});

ApiAuth.Enregistrer(app);
ApiReferentiels.Enregistrer(app);
ApiSaisies.Enregistrer(app);

app.Run();
return 0;

// ====================================================================
// Outil : dotnet Cra.Web.dll creer-admin <login> "<Nom affiche>"
// Cree le compte administrateur initial (aucun mot de passe en dur nulle part).
// ====================================================================
internal static class OutilCreerAdmin
{
    public static async Task<int> ExecuterAsync(string[] args)
    {
        if (args.Length < 3)
        {
            Console.WriteLine("Usage : dotnet Cra.Web.dll creer-admin <login> \"<Nom affiche>\"");
            Console.WriteLine("        dotnet Cra.Web.dll creer-utilisateur <login> \"<Nom affiche>\" <TECHNICIEN|MANAGER|ADMIN>");
            return 2;
        }
        var login = args[1].Trim().ToLowerInvariant();
        var nom = args[2].Trim();
        var role = args[0] == "creer-admin" ? "ADMIN" : (args.Length > 3 ? args[3].Trim().ToUpperInvariant() : "TECHNICIEN");
        if (role is not ("TECHNICIEN" or "MANAGER" or "ADMIN"))
        {
            Console.WriteLine("Role invalide : TECHNICIEN, MANAGER ou ADMIN.");
            return 2;
        }
        Console.Write("Mot de passe initial (12 caracteres mini) : ");
        var mdp = Console.ReadLine() ?? "";
        var probleme = MoteurRegles.ValiderMotDePasse(mdp);
        if (probleme is not null) { Console.WriteLine(probleme); return 2; }

        Bd.Initialiser();
        await using var cnx = await Bd.OuvrirAsync();
        var existe = await cnx.Commande("SELECT COUNT(*) FROM dbo.utilisateur WHERE login = @l;")
            .Param("@l", login).ScalaireAsync<int>();
        if (existe > 0) { Console.WriteLine($"Le login '{login}' existe deja."); return 2; }

        await using var tx = await cnx.BeginTransactionAsync();
        var id = await cnx.Commande(
            @"INSERT INTO dbo.utilisateur (login, nom_affichage, mdp_hash, doit_changer_mdp, statut, modifie_le)
              OUTPUT INSERTED.id VALUES (@l, @n, @h, @changer, 'ACTIF', SYSUTCDATETIME());", tx)
            .Param("@l", login).Param("@n", nom).Param("@h", MotsDePasse.Hacher(mdp)).Param("@changer", args[0] != "creer-admin")
            .ScalaireAsync<int>();
        await cnx.Commande(
            "INSERT INTO dbo.utilisateur_role (utilisateur_id, role_id) SELECT @u, id FROM dbo.role WHERE code = @r;", tx)
            .Param("@u", id).Param("@r", role).ExecAsync();
        await Audit.EcrireAsync(cnx, tx, id, "CREATION_UTILISATEUR", "utilisateur", id,
            null, new { login, nom, role }, "creation de compte via l'outil d'installation", null);
        await tx.CommitAsync();
        Console.WriteLine($"Compte {role} '{login}' cree (id {id}).");
        return 0;
    }
}

// ====================================================================
// Authentification et compte
// ====================================================================
internal static class ApiAuth
{
    private sealed record DemandeConnexion(string? Login, string? Mdp);
    private sealed record DemandeChangementMdp(string? Actuel, string? Nouveau);

    public static void Enregistrer(WebApplication app)
    {
        app.MapPost("/api/connexion", async (HttpContext ctx, DemandeConnexion d, CancellationToken ct) =>
        {
            var login = (d.Login ?? "").Trim().ToLowerInvariant();
            if (login.Length == 0 || string.IsNullOrEmpty(d.Mdp))
            {
                return Http.Erreur(ctx, 400, "CHAMP_REQUIS", "Identifiant et mot de passe requis.");
            }

            await using var cnx = await Bd.OuvrirAsync(ct);
            var u = (await cnx.Commande(
                @"SELECT id, nom_affichage, mdp_hash, statut, doit_changer_mdp, echecs_connexion, verrouille_jusqua
                  FROM dbo.utilisateur WHERE login = @l;")
                .Param("@l", login)
                .LireAsync(l => new
                {
                    Id = l.GetInt32(0),
                    Nom = l.GetString(1),
                    Hash = l.GetString(2),
                    Statut = l.GetString(3),
                    DoitChanger = l.GetBoolean(4),
                    Echecs = (int)l.GetInt16(5),
                    VerrouJusqua = l.IsDBNull(6) ? (DateTime?)null : l.GetDateTime(6)
                }, ct)).FirstOrDefault();

            if (u is null)
            {
                await Audit.EcrireAsync(cnx, null, null, "ECHEC_CONNEXION", "session", null, null, null,
                    $"login inconnu '{login}'", ctx, ct);
                return Http.Erreur(ctx, 401, "IDENTIFIANTS_INVALIDES", "Identifiants invalides.");
            }
            if (u.Statut != "ACTIF")
            {
                await Audit.EcrireAsync(cnx, null, u.Id, "ECHEC_CONNEXION", "session", null, null, null,
                    "compte non actif", ctx, ct);
                return Http.Erreur(ctx, 403, "COMPTE_INACTIF", "Compte desactive ou archive - contactez l'administrateur.");
            }
            if (u.VerrouJusqua is not null && u.VerrouJusqua > DateTime.UtcNow)
            {
                return Http.Erreur(ctx, 403, "COMPTE_VERROUILLE",
                    "Compte temporairement verrouille apres plusieurs echecs. Reessayez dans quelques minutes.");
            }
            if (!MotsDePasse.Verifier(d.Mdp!, u.Hash))
            {
                var echecs = u.Echecs + 1;
                if (echecs >= 5)
                {
                    await cnx.Commande(
                        "UPDATE dbo.utilisateur SET echecs_connexion = 0, verrouille_jusqua = DATEADD(MINUTE, 15, SYSUTCDATETIME()) WHERE id = @id;")
                        .Param("@id", u.Id).ExecAsync(ct);
                }
                else
                {
                    await cnx.Commande("UPDATE dbo.utilisateur SET echecs_connexion = @e WHERE id = @id;")
                        .Param("@e", echecs).Param("@id", u.Id).ExecAsync(ct);
                }
                await Audit.EcrireAsync(cnx, null, u.Id, "ECHEC_CONNEXION", "session", null, null, null,
                    echecs >= 5 ? "mot de passe errone - compte verrouille 15 min" : "mot de passe errone", ctx, ct);
                return Http.Erreur(ctx, 401, "IDENTIFIANTS_INVALIDES", "Identifiants invalides.");
            }

            await cnx.Commande("UPDATE dbo.utilisateur SET echecs_connexion = 0, verrouille_jusqua = NULL WHERE id = @id;")
                .Param("@id", u.Id).ExecAsync(ct);
            var roles = await cnx.Commande(
                @"SELECT r.code FROM dbo.utilisateur_role ur JOIN dbo.role r ON r.id = ur.role_id WHERE ur.utilisateur_id = @id;")
                .Param("@id", u.Id).LireAsync(l => l.GetString(0), ct);

            var revendications = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, u.Id.ToString()),
                new(ClaimTypes.Name, u.Nom)
            };
            revendications.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r)));
            await ctx.SignInAsync(new ClaimsPrincipal(new ClaimsIdentity(revendications,
                CookieAuthenticationDefaults.AuthenticationScheme)));

            await Audit.EcrireAsync(cnx, null, u.Id, "CONNEXION", "session", null, null, null, null, ctx, ct);
            return Results.Json(new { id = u.Id, nom = u.Nom, roles, doitChangerMdp = u.DoitChanger });
        });

        app.MapPost("/api/deconnexion", async (HttpContext ctx, CancellationToken ct) =>
        {
            if (ctx.User.Identity?.IsAuthenticated == true)
            {
                await using var cnx = await Bd.OuvrirAsync(ct);
                await Audit.EcrireAsync(cnx, null, ctx.IdUtilisateur(), "DECONNEXION", "session", null, null, null, null, ctx, ct);
            }
            await ctx.SignOutAsync();
            return Results.Json(new { ok = true });
        });

        app.MapGet("/api/moi", async (HttpContext ctx, CancellationToken ct) =>
        {
            await using var cnx = await Bd.OuvrirAsync(ct);
            var id = ctx.IdUtilisateur();
            var u = (await cnx.Commande(
                "SELECT nom_affichage, statut, doit_changer_mdp FROM dbo.utilisateur WHERE id = @id;")
                .Param("@id", id)
                .LireAsync(l => new { Nom = l.GetString(0), Statut = l.GetString(1), DoitChanger = l.GetBoolean(2) }, ct))
                .FirstOrDefault();
            if (u is null || u.Statut != "ACTIF")
            {
                await ctx.SignOutAsync(); // compte desactive/archive/supprime depuis la connexion
                return Results.StatusCode(401);
            }
            var roles = ctx.User.FindAll(ClaimTypes.Role).Select(c => c.Value).ToArray();
            return Results.Json(new { id, nom = u.Nom, roles, doitChangerMdp = u.DoitChanger });
        }).RequireAuthorization();

        app.MapPost("/api/moi/mot-de-passe", async (HttpContext ctx, DemandeChangementMdp d, CancellationToken ct) =>
        {
            var probleme = MoteurRegles.ValiderMotDePasse(d.Nouveau);
            if (string.IsNullOrEmpty(d.Actuel))
            {
                return Http.Erreur(ctx, 400, "CHAMP_REQUIS", "Saisissez votre mot de passe actuel.");
            }
            if (probleme is not null) { return Http.Erreur(ctx, 400, "MDP_INVALIDE", probleme); }
            if (d.Nouveau == d.Actuel)
            {
                return Http.Erreur(ctx, 400, "MDP_INVALIDE", "Le nouveau mot de passe doit etre different de l'actuel.");
            }

            var id = ctx.IdUtilisateur();
            await using var cnx = await Bd.OuvrirAsync(ct);
            var hash = await cnx.Commande("SELECT mdp_hash FROM dbo.utilisateur WHERE id = @id;")
                .Param("@id", id).ScalaireAsync<string>(ct);
            if (hash is null || !MotsDePasse.Verifier(d.Actuel!, hash))
            {
                return Http.Erreur(ctx, 400, "MDP_INVALIDE", "Mot de passe actuel incorrect.");
            }
            await using var tx = await cnx.BeginTransactionAsync(ct);
            await cnx.Commande(
                "UPDATE dbo.utilisateur SET mdp_hash = @h, doit_changer_mdp = 0, modifie_le = SYSUTCDATETIME() WHERE id = @id;", tx)
                .Param("@h", MotsDePasse.Hacher(d.Nouveau!)).Param("@id", id).ExecAsync(ct);
            await Audit.EcrireAsync(cnx, tx, id, "CHANGEMENT_MDP", "utilisateur", id, null, null,
                "mot de passe change par l'utilisateur lui-meme", ctx, ct);
            await tx.CommitAsync(ct);
            return Results.Json(new { ok = true });
        }).RequireAuthorization();
    }
}

// ====================================================================
// Referentiels (lecture, pour l'interface)
// ====================================================================
internal static class ApiReferentiels
{
    public static void Enregistrer(WebApplication app)
    {
        app.MapGet("/api/referentiels", async (HttpContext ctx, CancellationToken ct) =>
        {
            await using var cnx = await Bd.OuvrirAsync(ct);
            var ttks = await cnx.Commande("SELECT id, libelle, est_actif FROM dbo.ttk ORDER BY libelle;")
                .LireAsync(l => new { id = l.GetInt32(0), libelle = l.GetString(1), actif = l.GetBoolean(2) }, ct);
            var projets = await cnx.Commande("SELECT id, libelle, est_actif FROM dbo.projet ORDER BY libelle;")
                .LireAsync(l => new { id = l.GetInt32(0), libelle = l.GetString(1), actif = l.GetBoolean(2) }, ct);
            var feries = await cnx.Commande("SELECT date_ferie FROM dbo.jour_ferie;")
                .LireAsync(l => DateOnly.FromDateTime(l.GetDateTime(0)).ToString("yyyy-MM-dd"), ct);
            var parametres = await cnx.Commande("SELECT cle, valeur FROM dbo.parametre;")
                .LireAsync(l => (Cle: l.GetString(0), Valeur: l.GetString(1)), ct);
            int Parametre(string cle, int defaut)
                => parametres.Where(p => p.Cle == cle).Select(p => int.TryParse(p.Valeur, out var v) ? v : defaut).FirstOrDefault(defaut);
            return Results.Json(new
            {
                ttks, projets, feries,
                minutesJourCible = Parametre("minutes_jour_cible", 450),
                fenetreModificationMois = Parametre("fenetre_modification_mois", 1)
            });
        }).RequireAuthorization();
    }
}
